function player() {
  chrome.tabs.create({url: chrome.runtime.getURL("game.html")}, e => {
  })
}
chrome.action.onClicked.addListener(player);
chrome.runtime.onInstalled.addListener(e => {
  "install" === e.reason && player()
});